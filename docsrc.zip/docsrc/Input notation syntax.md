# Input notation syntax
