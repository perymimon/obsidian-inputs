# Global API and Context
